# Get Your APK in 5 Minutes (From Your Phone)

## Step 1 — Create free GitHub account
Go to: https://github.com/signup
(Use your phone browser — works fine)

## Step 2 — Create new repository
1. Tap the "+" icon → "New repository"
2. Name it: `365days`
3. Set to **Public**
4. Tap "Create repository"

## Step 3 — Upload the project files
1. On the repository page, tap "uploading an existing file"
2. Extract the ZIP I gave you
3. Upload ALL files (keep folder structure)
4. Tap "Commit changes"

## Step 4 — Watch it build automatically
1. Tap the "Actions" tab on your repo
2. You'll see "Build APK" running (green spinner)
3. Wait ~4 minutes

## Step 5 — Download your APK
1. Click the completed workflow run
2. Scroll down to "Artifacts"
3. Tap "365Days-APK" → downloads a zip
4. Extract it → you have `app-debug.apk`
5. Install it on your phone!

## Enable "Install unknown apps"
Settings → Security → Install unknown apps → Your browser → Allow
