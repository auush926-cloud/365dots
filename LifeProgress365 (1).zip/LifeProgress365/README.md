# 365 Days — Life Progress Wallpaper App

A premium AMOLED wallpaper app that marks each passing day of the year with a deep red dot.
365 dots. One fills per day. A personal quote for every single day.

---

## What it does

- Pure black (#000000) AMOLED background — zero battery drain on OLED screens
- 365 dots in a 21×18 grid, centered with breathing room on all sides
- Each passing day turns one dot deep red (#8B1A1A)
- A unique personal quote for every day of the year
- Auto-updates your wallpaper every midnight via WorkManager
- Long-press any dot → see its exact date
- No internet. No accounts. No tracking. Ever.

---

## How to Build

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 8+
- Android SDK 34
- A physical Android device (API 26+) or emulator

### Steps

1. **Open in Android Studio**
   ```
   File → Open → select the LifeProgress365 folder
   ```

2. **Let Gradle sync** (first time downloads dependencies ~2 min)

3. **Run on device**
   ```
   Run → Run 'app'
   ```
   Or build APK:
   ```
   Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```
   APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`

4. **Install via ADB** (if sideloading)
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

---

## First Launch

1. App opens to onboarding screen
2. Set your year start date (defaults to Jan 1)
3. Tap **BEGIN**
4. Wallpaper is applied immediately
5. Every midnight, WorkManager silently updates it — one new red dot appears

---

## How wallpaper auto-update works

- `WorkScheduler.java` calculates ms until next 00:00:05
- Enqueues a `OneTimeWorkRequest` via WorkManager
- `DailyWorker.java` runs at midnight, renders bitmap, applies wallpaper
- Worker re-schedules itself for the next midnight before exiting
- `BootReceiver.java` re-schedules after device reboot
- Total background runtime: ~200ms/day. Battery impact: negligible.

---

## Project Structure

```
app/src/main/java/com/life/progress365/
├── MainActivity.java          — Main screen, preview, settings, long-press
├── OnboardingActivity.java    — First-launch flow
├── WallpaperPreviewView.java  — Custom View: live dot grid in-app
├── WallpaperRenderer.java     — Core bitmap renderer (used for actual wallpaper)
├── WallpaperUpdater.java      — Applies bitmap via WallpaperManager
├── DailyWorker.java           — WorkManager task (midnight job)
├── WorkScheduler.java         — Schedules midnight WorkManager job
├── BootReceiver.java          — Reschedules after reboot
├── PrefsManager.java          — All SharedPreferences (start date, settings)
└── DailyQuotes.java           — 365 personal daily quotes

app/src/main/res/
├── layout/
│   ├── activity_main.xml
│   └── activity_onboarding.xml
├── drawable/
│   ├── dot_active.xml         — Red circle
│   ├── dot_inactive.xml       — White circle
│   ├── surface_rounded.xml    — Dark surface card
│   ├── btn_red.xml            — Red solid button
│   ├── btn_outline_red.xml    — Red outline button
│   ├── switch_thumb.xml       — Toggle thumb
│   ├── switch_track.xml       — Toggle track
│   └── ic_launcher_foreground.xml
└── values/
    ├── strings.xml
    ├── colors.xml
    └── themes.xml
```

---

## Permissions Required

| Permission | Why |
|---|---|
| `SET_WALLPAPER` | Apply the rendered bitmap as wallpaper |
| `RECEIVE_BOOT_COMPLETED` | Reschedule midnight job after reboot |
| `FOREGROUND_SERVICE` | WorkManager compatibility |
| `POST_NOTIFICATIONS` | Android 13+ WorkManager requirement |

---

## Design System

| Token | Value | Use |
|---|---|---|
| Background | `#000000` | True AMOLED black |
| Dot active | `#8B1A1A` | Past days (deep muted crimson) |
| Dot inactive | `#E8E8E8` | Future days (warm white) |
| Dot missed | `#2A2A2A` | Optional missed-day state |
| Surface | `#111111` | Card backgrounds |
| Border | `#2A2A2A` | Subtle outlines |
| Text dim | `#3A3A3A` | Whisper-level labels |

Grid: **21 columns × 18 rows** = 378 slots, 365 used.
Dot diameter: **8dp**. Gaps: **10dp H / 10dp V**.

---

## Troubleshooting

**Wallpaper not applying?**
- Android 13+ requires explicit `SET_WALLPAPER` permission
- Go to Settings → Apps → 365 Days → Permissions → enable if needed
- Some OEMs (Xiaomi, Samsung) restrict background wallpaper setting
- Use the **"Apply Wallpaper Now"** button as manual fallback

**WorkManager not firing at midnight?**
- On aggressive battery-saver ROMs (MIUI, ColorOS), add app to battery whitelist
- Settings → Battery → App launch / Battery optimization → 365 Days → Unrestricted

**Year not resetting?**
- Change start date to Jan 1 of new year in Settings
- The app resets automatically if start date = Jan 1 and new year begins

---

## License
MIT — build it, ship it, make it yours.
