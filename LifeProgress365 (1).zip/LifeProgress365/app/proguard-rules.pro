-keep class com.life.progress365.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
