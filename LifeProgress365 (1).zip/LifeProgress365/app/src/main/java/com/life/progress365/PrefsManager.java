package com.life.progress365;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;

/**
 * All app state lives here in SharedPreferences.
 * No cloud, no database, no network. Intentional.
 */
public class PrefsManager {

    private static final String PREFS_NAME       = "life_progress_prefs";
    private static final String KEY_START_YEAR   = "start_year";
    private static final String KEY_START_MONTH  = "start_month";   // 1-based
    private static final String KEY_START_DAY    = "start_day";
    private static final String KEY_ONBOARDED    = "onboarded";
    private static final String KEY_AUTO_WALLPAPER = "auto_wallpaper";
    private static final String KEY_SHOW_MISSED  = "show_missed";

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ── Onboarding ───────────────────────────────────────────────
    public boolean isOnboarded() {
        return prefs.getBoolean(KEY_ONBOARDED, false);
    }

    public void setOnboarded(boolean onboarded) {
        prefs.edit().putBoolean(KEY_ONBOARDED, onboarded).apply();
    }

    // ── Start date ───────────────────────────────────────────────
    public void setStartDate(int year, int month, int day) {
        prefs.edit()
                .putInt(KEY_START_YEAR, year)
                .putInt(KEY_START_MONTH, month)
                .putInt(KEY_START_DAY, day)
                .apply();
    }

    public int getStartYear() {
        return prefs.getInt(KEY_START_YEAR, Calendar.getInstance().get(Calendar.YEAR));
    }

    public int getStartMonth() {
        return prefs.getInt(KEY_START_MONTH, 1);
    }

    public int getStartDay() {
        return prefs.getInt(KEY_START_DAY, 1);
    }

    /**
     * Returns how many days have elapsed since the start date (inclusive of today).
     * Minimum 1, maximum 365/366.
     */
    public int getElapsedDays() {
        try {
            LocalDate start = LocalDate.of(getStartYear(), getStartMonth(), getStartDay());
            LocalDate today = LocalDate.now();
            long days = ChronoUnit.DAYS.between(start, today) + 1; // +1 = today counts
            int maxDays = start.isLeapYear() ? 366 : 365;
            return (int) Math.max(1, Math.min(days, maxDays));
        } catch (Exception e) {
            return 1;
        }
    }

    /**
     * Returns the day of year for today (1-365/366), used to pick the daily quote.
     */
    public int getTodayDayOfYear() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.DAY_OF_YEAR);
    }

    // ── Settings ─────────────────────────────────────────────────
    public boolean isAutoWallpaperEnabled() {
        return prefs.getBoolean(KEY_AUTO_WALLPAPER, true);
    }

    public void setAutoWallpaper(boolean enabled) {
        prefs.edit().putBoolean(KEY_AUTO_WALLPAPER, enabled).apply();
    }

    public boolean isShowMissedEnabled() {
        return prefs.getBoolean(KEY_SHOW_MISSED, true);
    }

    public void setShowMissed(boolean enabled) {
        prefs.edit().putBoolean(KEY_SHOW_MISSED, enabled).apply();
    }

    /**
     * Returns formatted start date string for display.
     */
    public String getStartDateDisplayString() {
        String[] months = {"January","February","March","April","May","June",
                "July","August","September","October","November","December"};
        int m = getStartMonth() - 1;
        if (m < 0 || m > 11) m = 0;
        return months[m] + " " + getStartDay() + ", " + getStartYear();
    }
}
