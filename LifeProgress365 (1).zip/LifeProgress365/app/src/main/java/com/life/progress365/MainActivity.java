package com.life.progress365;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private PrefsManager prefs;
    private WallpaperPreviewView previewView;
    private TextView tvDayCount;
    private TextView tvQuote;
    private TextView tvStartDate;
    private Switch switchAutoWallpaper;

    // Long press detection
    private final Handler longPressHandler = new Handler(Looper.getMainLooper());
    private static final long LONG_PRESS_MS = 500;
    private boolean longPressTriggered = false;
    private int hoveredDotIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = new PrefsManager(this);

        // Route to onboarding if first launch
        if (!prefs.isOnboarded()) {
            startActivity(new Intent(this, OnboardingActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        previewView     = findViewById(R.id.preview_view);
        tvDayCount      = findViewById(R.id.tv_day_count);
        tvQuote         = findViewById(R.id.tv_quote);
        tvStartDate     = findViewById(R.id.tv_start_date);
        switchAutoWallpaper = findViewById(R.id.switch_auto_wallpaper);

        refreshUI();
        setupLongPress();
        setupSettings();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUI();
    }

    private void refreshUI() {
        int elapsed   = prefs.getElapsedDays();
        int dayOfYear = prefs.getTodayDayOfYear();
        int year      = Calendar.getInstance().get(Calendar.YEAR);
        int total     = ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) ? 366 : 365;

        previewView.setData(elapsed, dayOfYear);
        tvDayCount.setText("Day " + elapsed + " of " + total);
        tvQuote.setText(DailyQuotes.getQuoteForDay(dayOfYear));
        tvStartDate.setText(prefs.getStartDateDisplayString());
        switchAutoWallpaper.setChecked(prefs.isAutoWallpaperEnabled());
    }

    // ── Long press on the dot grid ───────────────────────────────
    private void setupLongPress() {
        previewView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    longPressTriggered = false;
                    int dotIdx = getDotAtPosition(event.getX(), event.getY());
                    if (dotIdx > 0) {
                        hoveredDotIndex = dotIdx;
                        longPressHandler.postDelayed(() -> {
                            longPressTriggered = true;
                            previewView.showTooltipForDot(hoveredDotIndex, event.getX(), event.getY());
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                        }, LONG_PRESS_MS);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    longPressHandler.removeCallbacksAndMessages(null);
                    if (longPressTriggered) {
                        previewView.hideTooltip();
                    }
                    break;
            }
            return true;
        });
    }

    /**
     * Given touch coordinates, returns which dot was tapped (1-365), or -1 if none.
     */
    private int getDotAtPosition(float touchX, float touchY) {
        int w = previewView.getWidth();
        int h = previewView.getHeight();
        float density = w / 393f;
        float dotD = 8f * density;
        float cellW = dotD + 10f * density;
        float cellH = dotD + 10f * density;
        float gridW = 21 * cellW - 10f * density;
        float gridH = ((int) Math.ceil(365.0 / 21)) * cellH - 10f * density;
        float gridX = (w - gridW) / 2f;
        float gridY = (h - gridH) / 2f - 40f * density;

        float relX = touchX - gridX;
        float relY = touchY - gridY;
        int col = (int) (relX / cellW);
        int row = (int) (relY / cellH);

        if (col < 0 || col >= 21 || row < 0) return -1;
        int idx = row * 21 + col + 1;
        return (idx >= 1 && idx <= 365) ? idx : -1;
    }

    // ── Settings ─────────────────────────────────────────────────
    private void setupSettings() {
        // Change start date
        findViewById(R.id.row_start_date).setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            int y = prefs.getStartYear();
            int m = prefs.getStartMonth() - 1;
            int d = prefs.getStartDay();
            new DatePickerDialog(this, R.style.DatePickerTheme,
                    (view, year, month, day) -> {
                        prefs.setStartDate(year, month + 1, day);
                        refreshUI();
                        applyWallpaperAsync();
                    }, y, m, d).show();
        });

        // Auto wallpaper toggle
        switchAutoWallpaper.setOnCheckedChangeListener((btn, isChecked) -> {
            prefs.setAutoWallpaper(isChecked);
            if (isChecked) {
                WorkScheduler.scheduleNextMidnight(this);
                Toast.makeText(this, "Wallpaper will update daily at midnight", Toast.LENGTH_SHORT).show();
            } else {
                WorkScheduler.cancelAll(this);
                Toast.makeText(this, "Auto-update paused", Toast.LENGTH_SHORT).show();
            }
        });

        // Manual apply button
        findViewById(R.id.btn_apply_now).setOnClickListener(v -> {
            Toast.makeText(this, "Applying wallpaper…", Toast.LENGTH_SHORT).show();
            applyWallpaperAsync();
        });
    }

    private void applyWallpaperAsync() {
        new Thread(() -> {
            boolean ok = WallpaperUpdater.applyWallpaper(MainActivity.this);
            runOnUiThread(() -> {
                if (ok) {
                    Toast.makeText(this, "Wallpaper updated!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed — check wallpaper permission", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }
}
