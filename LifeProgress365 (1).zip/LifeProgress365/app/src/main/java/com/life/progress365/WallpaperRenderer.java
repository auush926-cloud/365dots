package com.life.progress365;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.DisplayMetrics;

import java.util.Calendar;

/**
 * Pure drawing engine. Renders the 365-dot wallpaper bitmap.
 * No Android UI dependencies — runs perfectly on a background thread.
 */
public class WallpaperRenderer {

    // ── Design tokens ───────────────────────────────────────────
    private static final int COLOR_BG       = Color.BLACK;
    private static final int COLOR_INACTIVE = Color.parseColor("#E8E8E8");
    private static final int COLOR_ACTIVE   = Color.parseColor("#8B1A1A");
    private static final int COLOR_MISSED   = Color.parseColor("#2A2A2A");
    private static final int COLOR_DIM      = Color.parseColor("#3A3A3A");
    private static final int COLOR_PROGRESS = Color.parseColor("#8B1A1A");

    // ── Grid config ─────────────────────────────────────────────
    private static final int COLS = 21;
    private static final int TOTAL_DOTS = 365;
    private static final int ROWS = (int) Math.ceil((double) TOTAL_DOTS / COLS); // 18

    public static Bitmap render(int screenWidth, int screenHeight, int elapsedDays, int dayOfYear) {
        Bitmap bmp = Bitmap.createBitmap(screenWidth, screenHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);

        // Background
        canvas.drawColor(COLOR_BG);

        float density = screenWidth / 393f; // relative to 393dp base

        float dotDiameter = 8f * density;
        float gapH = 10f * density;
        float gapV = 10f * density;
        float cellW = dotDiameter + gapH;
        float cellH = dotDiameter + gapV;

        float gridW = COLS * cellW - gapH;
        float gridH = ROWS * cellH - gapV;

        float gridX = (screenWidth - gridW) / 2f;
        // Place grid slightly above center for quote space below
        float gridY = (screenHeight - gridH) / 2f - (40f * density);

        Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float radius = dotDiameter / 2f;

        // Draw dots
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                int dotIndex = i * COLS + j + 1;
                if (dotIndex > TOTAL_DOTS) break;

                float cx = gridX + j * cellW + radius;
                float cy = gridY + i * cellH + radius;

                if (dotIndex <= elapsedDays) {
                    // Past / today — deep red
                    dotPaint.setColor(COLOR_ACTIVE);
                    dotPaint.setAlpha(235);
                } else {
                    // Future — white
                    dotPaint.setColor(COLOR_INACTIVE);
                    dotPaint.setAlpha(110);
                }

                canvas.drawCircle(cx, cy, radius, dotPaint);
            }
        }

        // ── Year label (top of grid) ─────────────────────────────
        float textSize = 11f * density;
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        textPaint.setTextSize(textSize);
        textPaint.setColor(COLOR_DIM);
        textPaint.setAlpha(100);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setLetterSpacing(0.2f);

        int year = Calendar.getInstance().get(Calendar.YEAR);
        canvas.drawText(String.valueOf(year), screenWidth / 2f, gridY - 20f * density, textPaint);

        // ── Day counter (below grid) ─────────────────────────────
        textPaint.setAlpha(90);
        textPaint.setLetterSpacing(0.15f);
        int totalDaysInYear = isLeapYear(year) ? 366 : 365;
        canvas.drawText("DAY  " + elapsedDays + "  OF  " + totalDaysInYear,
                screenWidth / 2f, gridY + gridH + 22f * density, textPaint);

        // ── Progress bar ─────────────────────────────────────────
        float barW = 100f * density;
        float barX = (screenWidth - barW) / 2f;
        float barY = gridY + gridH + 32f * density;

        Paint barBgPaint = new Paint();
        barBgPaint.setColor(COLOR_DIM);
        barBgPaint.setAlpha(50);
        canvas.drawRect(barX, barY, barX + barW, barY + 1f * density, barBgPaint);

        Paint barFillPaint = new Paint();
        barFillPaint.setColor(COLOR_PROGRESS);
        barFillPaint.setAlpha(180);
        float fillW = barW * ((float) elapsedDays / totalDaysInYear);
        canvas.drawRect(barX, barY, barX + fillW, barY + 1f * density, barFillPaint);

        // Percentage
        float pct = (float) elapsedDays / totalDaysInYear * 100f;
        String pctStr = String.format("%.1f%%", pct);
        textPaint.setTextSize(9f * density);
        textPaint.setAlpha(70);
        textPaint.setLetterSpacing(0.1f);
        canvas.drawText(pctStr, screenWidth / 2f, barY + 12f * density, textPaint);

        // ── Daily quote ──────────────────────────────────────────
        String quote = DailyQuotes.getQuoteForDay(dayOfYear);
        float quoteSize = 11f * density;
        textPaint.setTextSize(quoteSize);
        textPaint.setAlpha(120);
        textPaint.setLetterSpacing(0.02f);
        textPaint.setTypeface(Typeface.create("sans-serif-light", Typeface.ITALIC));

        float quoteY = barY + 32f * density;
        float maxQuoteW = screenWidth - 80f * density;
        drawWrappedText(canvas, textPaint, quote, screenWidth / 2f, quoteY, maxQuoteW, 16f * density);

        return bmp;
    }

    /**
     * Draws text wrapping to multiple lines centered at x.
     */
    private static void drawWrappedText(Canvas canvas, Paint paint, String text,
                                        float cx, float startY, float maxWidth, float lineHeight) {
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        float y = startY;

        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (paint.measureText(test) > maxWidth && line.length() > 0) {
                canvas.drawText(line.toString(), cx, y, paint);
                y += lineHeight;
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) {
            canvas.drawText(line.toString(), cx, y, paint);
        }
    }

    private static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
}
