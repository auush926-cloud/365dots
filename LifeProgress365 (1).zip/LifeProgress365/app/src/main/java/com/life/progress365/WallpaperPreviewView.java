package com.life.progress365;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.Calendar;

/**
 * Custom View that renders the 365-dot grid live inside the app.
 * Matches WallpaperRenderer exactly but draws directly to View canvas.
 * Supports long-press to show date tooltip.
 */
public class WallpaperPreviewView extends View {

    private static final int COLOR_BG       = Color.BLACK;
    private static final int COLOR_INACTIVE = Color.parseColor("#E8E8E8");
    private static final int COLOR_ACTIVE   = Color.parseColor("#8B1A1A");
    private static final int COLOR_DIM      = Color.parseColor("#3A3A3A");

    private static final int COLS = 21;
    private static final int TOTAL_DOTS = 365;
    private static final int ROWS = (int) Math.ceil((double) TOTAL_DOTS / COLS);

    private int elapsedDays = 1;
    private int dayOfYear   = 1;

    private Paint dotPaint;
    private Paint textPaint;
    private Paint barPaint;

    // Tooltip state
    private int tooltipDot = -1;
    private float tooltipX, tooltipY;

    public WallpaperPreviewView(Context context) {
        super(context);
        init();
    }

    public WallpaperPreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setBackgroundColor(COLOR_BG);
        dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint = new Paint();
    }

    public void setData(int elapsed, int dayOfYear) {
        this.elapsedDays = elapsed;
        this.dayOfYear   = dayOfYear;
        invalidate();
    }

    public void showTooltipForDot(int dotIndex, float x, float y) {
        tooltipDot = dotIndex;
        tooltipX = x;
        tooltipY = y;
        invalidate();
    }

    public void hideTooltip() {
        tooltipDot = -1;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();

        float density = w / 393f;
        float dotD    = 8f * density;
        float gapH    = 10f * density;
        float gapV    = 10f * density;
        float cellW   = dotD + gapH;
        float cellH   = dotD + gapV;
        float gridW   = COLS * cellW - gapH;
        float gridH   = ROWS * cellH - gapV;
        float gridX   = (w - gridW) / 2f;
        float gridY   = (h - gridH) / 2f - 40f * density;
        float radius  = dotD / 2f;

        // Draw dots
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                int idx = i * COLS + j + 1;
                if (idx > TOTAL_DOTS) break;

                float cx = gridX + j * cellW + radius;
                float cy = gridY + i * cellH + radius;

                boolean isActive = idx <= elapsedDays;
                boolean isHL = idx == tooltipDot;

                dotPaint.setColor(isActive ? COLOR_ACTIVE : COLOR_INACTIVE);
                dotPaint.setAlpha(isHL ? 255 : isActive ? 235 : 110);
                canvas.drawCircle(cx, cy, isHL ? radius * 1.5f : radius, dotPaint);

                if (isHL) {
                    dotPaint.setColor(COLOR_ACTIVE);
                    dotPaint.setAlpha(100);
                    dotPaint.setStyle(Paint.Style.STROKE);
                    dotPaint.setStrokeWidth(1.5f * density);
                    canvas.drawCircle(cx, cy, radius * 2.3f, dotPaint);
                    dotPaint.setStyle(Paint.Style.FILL);
                }
            }
        }

        // Year label
        int year = Calendar.getInstance().get(Calendar.YEAR);
        textPaint.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        textPaint.setTextSize(11f * density);
        textPaint.setColor(COLOR_DIM);
        textPaint.setAlpha(110);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setLetterSpacing(0.2f);
        canvas.drawText(String.valueOf(year), w / 2f, gridY - 20f * density, textPaint);

        // Day counter
        int total = isLeapYear(year) ? 366 : 365;
        textPaint.setAlpha(95);
        textPaint.setLetterSpacing(0.15f);
        canvas.drawText("DAY  " + elapsedDays + "  OF  " + total,
                w / 2f, gridY + gridH + 22f * density, textPaint);

        // Progress bar track
        float barW  = 100f * density;
        float barX  = (w - barW) / 2f;
        float barY  = gridY + gridH + 32f * density;
        barPaint.setColor(COLOR_DIM);
        barPaint.setAlpha(50);
        canvas.drawRect(barX, barY, barX + barW, barY + density, barPaint);

        // Progress bar fill
        barPaint.setColor(COLOR_ACTIVE);
        barPaint.setAlpha(180);
        canvas.drawRect(barX, barY, barX + barW * ((float) elapsedDays / total),
                barY + density, barPaint);

        // Percentage
        float pct = (float) elapsedDays / total * 100f;
        textPaint.setTextSize(9f * density);
        textPaint.setAlpha(75);
        textPaint.setLetterSpacing(0.1f);
        canvas.drawText(String.format("%.1f%%", pct), w / 2f, barY + 13f * density, textPaint);

        // Quote
        String quote = DailyQuotes.getQuoteForDay(dayOfYear);
        textPaint.setTextSize(11f * density);
        textPaint.setAlpha(125);
        textPaint.setTypeface(Typeface.create("sans-serif-light", Typeface.ITALIC));
        textPaint.setLetterSpacing(0.02f);
        float quoteY = barY + 32f * density;
        float maxQW  = w - 80f * density;
        drawWrappedText(canvas, textPaint, quote, w / 2f, quoteY, maxQW, 16f * density);

        // Tooltip pill
        if (tooltipDot > 0) {
            drawTooltipPill(canvas, density);
        }
    }

    private void drawTooltipPill(Canvas canvas, float density) {
        // Compute date for this dot
        int col = (tooltipDot - 1) % COLS;
        int row = (tooltipDot - 1) / COLS;
        int w = getWidth(), h = getHeight();
        float dotD = 8f * density;
        float cellW = dotD + 10f * density;
        float cellH = dotD + 10f * density;
        float gridW = COLS * cellW - 10f * density;
        float gridH = ROWS * cellH - 10f * density;
        float gridX = (w - gridW) / 2f;
        float gridY = (h - gridH) / 2f - 40f * density;
        float cx = gridX + col * cellW + dotD / 2f;
        float cy = gridY + row * cellH + dotD / 2f;

        // Build date label
        String label = getDotDateLabel(tooltipDot);

        float pillW = 65f * density;
        float pillH = 22f * density;
        float px = cx - pillW / 2f;
        float py = cy - pillH - 12f * density;

        // Pill background
        Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
        pill.setColor(Color.parseColor("#111111"));
        android.graphics.RectF rect = new android.graphics.RectF(px, py, px + pillW, py + pillH);
        canvas.drawRoundRect(rect, 6f * density, 6f * density, pill);
        pill.setColor(Color.parseColor("#2A2A2A"));
        pill.setStyle(Paint.Style.STROKE);
        pill.setStrokeWidth(0.5f * density);
        canvas.drawRoundRect(rect, 6f * density, 6f * density, pill);

        // Pill text
        textPaint.setColor(Color.parseColor("#E8E8E8"));
        textPaint.setAlpha(220);
        textPaint.setTextSize(10f * density);
        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        textPaint.setLetterSpacing(0.12f);
        canvas.drawText(label, px + pillW / 2f, py + pillH * 0.65f, textPaint);

        // Connector dots
        pill.setStyle(Paint.Style.FILL);
        pill.setColor(Color.parseColor("#2A2A2A"));
        pill.setAlpha(140);
        canvas.drawCircle(cx, py + pillH + 4f * density, 2f * density, pill);
        pill.setAlpha(70);
        canvas.drawCircle(cx, py + pillH + 9f * density, 1.5f * density, pill);
    }

    private String getDotDateLabel(int dotIndex) {
        // Map dot number to a calendar date based on start of year
        Calendar cal = Calendar.getInstance();
        int startYear = new PrefsManager(getContext()).getStartYear();
        cal.set(Calendar.YEAR, startYear);
        cal.set(Calendar.DAY_OF_YEAR, dotIndex);
        String[] months = {"JAN","FEB","MAR","APR","MAY","JUN",
                "JUL","AUG","SEP","OCT","NOV","DEC"};
        return months[cal.get(Calendar.MONTH)] + " " + cal.get(Calendar.DAY_OF_MONTH);
    }

    private void drawWrappedText(Canvas canvas, Paint paint, String text,
                                 float cx, float startY, float maxWidth, float lineHeight) {
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        float y = startY;
        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (paint.measureText(test) > maxWidth && line.length() > 0) {
                canvas.drawText(line.toString(), cx, y, paint);
                y += lineHeight;
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) canvas.drawText(line.toString(), cx, y, paint);
    }

    private boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
}
