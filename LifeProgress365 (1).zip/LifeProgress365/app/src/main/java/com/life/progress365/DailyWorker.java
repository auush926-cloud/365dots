package com.life.progress365;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/**
 * WorkManager job that fires once per day at midnight.
 * Renders + applies the wallpaper in < 300ms.
 * Battery-safe: no wake locks, no persistent service.
 */
public class DailyWorker extends Worker {

    private static final String TAG = "DailyWorker";

    public DailyWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.d(TAG, "DailyWorker running — updating wallpaper");

        PrefsManager prefs = new PrefsManager(getApplicationContext());
        if (!prefs.isAutoWallpaperEnabled()) {
            Log.d(TAG, "Auto wallpaper disabled, skipping");
            return Result.success();
        }

        boolean success = WallpaperUpdater.applyWallpaper(getApplicationContext());

        // Reschedule for next midnight
        WorkScheduler.scheduleNextMidnight(getApplicationContext());

        return success ? Result.success() : Result.retry();
    }
}
