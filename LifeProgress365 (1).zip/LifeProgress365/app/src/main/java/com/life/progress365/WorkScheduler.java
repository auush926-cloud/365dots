package com.life.progress365;

import android.content.Context;
import android.util.Log;

import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/**
 * Calculates delay until next midnight and enqueues DailyWorker.
 * Uses OneTimeWorkRequest chained from within DailyWorker itself,
 * which is more reliable than PeriodicWorkRequest on aggressive battery systems.
 */
public class WorkScheduler {

    private static final String WORK_TAG = "life_progress_daily";
    private static final String TAG = "WorkScheduler";

    public static void scheduleNextMidnight(Context context) {
        long delayMs = msUntilMidnight();
        Log.d(TAG, "Scheduling next wallpaper update in " + (delayMs / 60000) + " minutes");

        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(DailyWorker.class)
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .addTag(WORK_TAG)
                .build();

        WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_TAG,
                ExistingWorkPolicy.REPLACE,
                request
        );
    }

    public static void cancelAll(Context context) {
        WorkManager.getInstance(context).cancelAllWorkByTag(WORK_TAG);
    }

    /**
     * Returns milliseconds until the next 00:00:05 (5 seconds past midnight for safety).
     */
    private static long msUntilMidnight() {
        Calendar now = Calendar.getInstance();
        Calendar midnight = (Calendar) now.clone();
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 5);
        midnight.set(Calendar.MILLISECOND, 0);

        // If midnight has already passed today, schedule for tomorrow
        if (midnight.before(now)) {
            midnight.add(Calendar.DAY_OF_MONTH, 1);
        }

        return midnight.getTimeInMillis() - now.getTimeInMillis();
    }
}
