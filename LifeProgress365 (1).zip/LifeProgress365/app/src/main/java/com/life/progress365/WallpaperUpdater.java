package com.life.progress365;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.IOException;

/**
 * Applies the rendered bitmap as the home screen wallpaper.
 * Must be called from a background thread.
 */
public class WallpaperUpdater {

    private static final String TAG = "WallpaperUpdater";

    public static boolean applyWallpaper(Context context) {
        try {
            // Get real screen dimensions
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            int width  = dm.widthPixels;
            int height = dm.heightPixels;

            PrefsManager prefs = new PrefsManager(context);
            int elapsed  = prefs.getElapsedDays();
            int dayOfYear = prefs.getTodayDayOfYear();

            // Render the wallpaper bitmap (fast, off-thread)
            Bitmap bmp = WallpaperRenderer.render(width, height, elapsed, dayOfYear);

            // Apply it
            WallpaperManager wpm = WallpaperManager.getInstance(context);
            wpm.setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM);

            bmp.recycle();
            Log.d(TAG, "Wallpaper applied — day " + elapsed + " of 365");
            return true;

        } catch (IOException e) {
            Log.e(TAG, "Failed to apply wallpaper", e);
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Unexpected error applying wallpaper", e);
            return false;
        }
    }
}
