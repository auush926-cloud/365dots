package com.life.progress365;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class OnboardingActivity extends AppCompatActivity {

    private PrefsManager prefs;
    private int selectedYear, selectedMonth, selectedDay;
    private TextView tvDateValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        prefs = new PrefsManager(this);

        // Default start date = Jan 1 current year
        Calendar cal = Calendar.getInstance();
        selectedYear  = cal.get(Calendar.YEAR);
        selectedMonth = 1;
        selectedDay   = 1;

        tvDateValue = findViewById(R.id.tv_date_value);
        updateDateDisplay();

        // Date picker row
        findViewById(R.id.row_date).setOnClickListener(v -> showDatePicker());

        // BEGIN button
        Button btnBegin = findViewById(R.id.btn_begin);
        btnBegin.setOnClickListener(v -> onBegin());
    }

    private void showDatePicker() {
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                R.style.DatePickerTheme,
                (view, year, month, dayOfMonth) -> {
                    selectedYear  = year;
                    selectedMonth = month + 1; // DatePickerDialog is 0-based
                    selectedDay   = dayOfMonth;
                    updateDateDisplay();
                },
                selectedYear,
                selectedMonth - 1,
                selectedDay
        );
        // Restrict to current year only
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        dialog.show();
    }

    private void updateDateDisplay() {
        String[] months = {"January","February","March","April","May","June",
                "July","August","September","October","November","December"};
        tvDateValue.setText(months[selectedMonth - 1] + " " + selectedDay + ", " + selectedYear);
    }

    private void onBegin() {
        // Save start date
        prefs.setStartDate(selectedYear, selectedMonth, selectedDay);
        prefs.setOnboarded(true);
        prefs.setAutoWallpaper(true);

        // Apply wallpaper on background thread
        new Thread(() -> {
            WallpaperUpdater.applyWallpaper(OnboardingActivity.this);
            // Schedule midnight updates
            WorkScheduler.scheduleNextMidnight(OnboardingActivity.this);
        }).start();

        // Go to main
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
