package com.life.progress365;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Reschedules the midnight WorkManager job after device reboot.
 * Also applies wallpaper immediately on boot so it's never stale.
 */
public class BootReceiver extends BroadcastReceiver {

    private static final String TAG = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
                Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {

            Log.d(TAG, "Boot/update received — rescheduling and refreshing wallpaper");

            PrefsManager prefs = new PrefsManager(context);
            if (prefs.isOnboarded() && prefs.isAutoWallpaperEnabled()) {
                // Apply wallpaper immediately (async)
                new Thread(() -> WallpaperUpdater.applyWallpaper(context)).start();

                // Reschedule midnight job
                WorkScheduler.scheduleNextMidnight(context);
            }
        }
    }
}
